﻿using controleDeAluno.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace controleDeAluno.Controller
{
    internal class GerenciadorAluno
    {
        public void CadastrarAluno()
        {
            SqlConnection liAluno = new SqlConnection(Conexao.conectar());
            SqlCommand paluno = new SqlCommand("pCadastrar", liAluno);
            paluno.CommandType = CommandType.StoredProcedure;

            paluno.Parameters.AddWithValue("nome", Alunos.Nome);
            paluno.Parameters.AddWithValue("sala", Alunos.Sala);
            paluno.Parameters.AddWithValue("turma", Alunos.Turma);
            paluno.Parameters.AddWithValue("dtNascimento", Alunos.DtNascimento);
            paluno.Parameters.AddWithValue("media", Alunos.Media);

            liAluno.Open();
            paluno.ExecuteNonQuery();

            var resultado = MessageBox.Show("Peça Não cadastrada");

            
        }

        public void AlterarAluno()
        {
            SqlConnection liAluno = new SqlConnection(Conexao.conectar());
            SqlCommand pAluno = new SqlCommand("pAlterarAluno", liAluno);
            pAluno.CommandType = CommandType.StoredProcedure;

            try
            {
                pAluno.Parameters.AddWithValue("id", Alunos.Id);
                pAluno.Parameters.AddWithValue("nome", Alunos.Nome);
                pAluno.Parameters.AddWithValue("sala", Alunos.Sala);
                pAluno.Parameters.AddWithValue("turma", Alunos.Turma);
                pAluno.Parameters.AddWithValue("dtNascimento", Alunos.DtNascimento);
                pAluno.Parameters.AddWithValue("media", Alunos.Media);

                liAluno.Open();
                pAluno.ExecuteNonQuery();
            }
            catch (Exception)
            {

                throw;
            }
         } 

        public void DeletarAluno()
        {
            SqlConnection liAluno = new SqlConnection(Conexao.conectar());
            SqlCommand pAluno = new SqlCommand("pDeletarAluno", liAluno);
            pAluno.CommandType = CommandType.StoredProcedure;

            try
            {
              pAluno.Parameters.AddWithValue ("id", Alunos.Id);
                liAluno.Open();
               

            }
            catch (Exception)
            {

                throw;
            }
  

        }

        public static BindingSource BuscarN() 
        {
            SqlConnection liALuno = new SqlConnection(Conexao.conectar());
            SqlCommand pAluno = new SqlCommand("pBuscaNome", liALuno);
            pAluno.CommandType = CommandType.StoredProcedure;

            pAluno.Parameters.AddWithValue("nome", Alunos.Nome);
            liALuno.Open();
            pAluno.ExecuteNonQuery();

            SqlDataAdapter da = new SqlDataAdapter(pAluno);
            DataTable dt = new DataTable();

            da.Fill(dt);

            BindingSource dados = new BindingSource();
            dados.DataSource = dt;

            return dados;

        }
        public void Buscarid() 
        {
            SqlConnection liAluno = new SqlConnection(Conexao.conectar());
            SqlCommand pAluno = new SqlCommand("pBuscarID", liAluno);
            pAluno.CommandType = CommandType.StoredProcedure;

            try
            {
                pAluno.Parameters.AddWithValue("id", Alunos.Nome);
                liAluno.Open();
                pAluno.ExecuteNonQuery();
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
